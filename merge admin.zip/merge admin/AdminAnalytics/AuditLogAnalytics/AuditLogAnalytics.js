import React, { useState, useEffect } from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import TableSortLabel from '@mui/material/TableSortLabel';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import Button from '@mui/material/Button';


const mockdata = [
    {
      "UserId": 101,
      "UserName": "JohnDoe",
      "Timestamp": "2024-04-18T09:12:45",
      "Action": "Login",
      "Category": "Auth",
      "Details": "User logged in successfully",
      "IsSuccess": true
    },
    {
      "UserId": 102,
      "UserName": "JaneSmith",
      "Timestamp": "2024-04-17T14:23:21",
      "Action": "View Policy",
      "Category": "Policy",
      "Details": "User viewed policy details",
      "IsSuccess": true
    },
    {
      "UserId": 103,
      "UserName": "AliceJohnson",
      "Timestamp": "2024-04-16T10:45:32",
      "Action": "Update Profile",
      "Category": "Auth",
      "Details": "User updated profile information",
      "IsSuccess": true
    },
    {
      "UserId": 104,
      "UserName": "BobWilliams",
      "Timestamp": "2024-04-15T11:30:19",
      "Action": "Create Claim",
      "Category": "Claim",
      "Details": "User created a new claim",
      "IsSuccess": true
    },
    {
      "UserId": 105,
      "UserName": "EvaBrown",
      "Timestamp": "2024-04-14T08:57:11",
      "Action": "View Invoice",
      "Category": "Policy",
      "Details": "User viewed invoice details",
      "IsSuccess": true
    },
    {
      "UserId": 106,
      "UserName": "MichaelAdams",
      "Timestamp": "2024-04-13T16:42:35",
      "Action": "Update Policy",
      "Category": "Policy",
      "Details": "User updated policy information",
      "IsSuccess": true
    },
    {
      "UserId": 107,
      "UserName": "SophiaGarcia",
      "Timestamp": "2024-04-12T09:18:27",
      "Action": "Login",
      "Category": "Auth",
      "Details": "User logged in successfully",
      "IsSuccess": true
    },
    {
      "UserId": 108,
      "UserName": "DavidLee",
      "Timestamp": "2024-04-11T14:35:09",
      "Action": "Create Claim",
      "Category": "Claim",
      "Details": "User created a new claim",
      "IsSuccess": true
    },
    {
      "UserId": 109,
      "UserName": "OliviaTaylor",
      "Timestamp": "2024-04-10T11:27:54",
      "Action": "View Policy",
      "Category": "Policy",
      "Details": "User viewed policy details",
      "IsSuccess": true
    },
    {
      "UserId": 110,
      "UserName": "JamesClark",
      "Timestamp": "2024-04-09T08:45:36",
      "Action": "Update Profile",
      "Category": "Auth",
      "Details": "User updated profile information",
      "IsSuccess": true
    },
    {
      "UserId": 111,
      "UserName": "CharlotteMartinez",
      "Timestamp": "2024-04-08T15:20:47",
      "Action": "View Invoice",
      "Category": "Policy",
      "Details": "User viewed invoice details",
      "IsSuccess": true
    },
    {
      "UserId": 112,
      "UserName": "WilliamBrown",
      "Timestamp": "2024-04-07T10:11:29",
      "Action": "Create Claim",
      "Category": "Claim",
      "Details": "User created a new claim",
      "IsSuccess": true
    },
    {
      "UserId": 113,
      "UserName": "EmilyAnderson",
      "Timestamp": "2024-04-06T14:22:18",
      "Action": "Login",
      "Category": "Auth",
      "Details": "User logged in successfully",
      "IsSuccess": true
    },
    {
      "UserId": 114,
      "UserName": "BenjaminRodriguez",
      "Timestamp": "2024-04-05T09:34:57",
      "Action": "View Policy",
      "Category": "Policy",
      "Details": "User viewed policy details",
      "IsSuccess": true
    },
    {
      "UserId": 115,
      "UserName": "AmeliaGonzalez",
      "Timestamp": "2024-04-04T16:55:43",
      "Action": "Update Profile",
      "Category": "Auth",
      "Details": "User updated profile information",
      "IsSuccess": true
    },
    {
      "UserId": 116,
      "UserName": "HenryPerez",
      "Timestamp": "2024-04-03T11:39:22",
      "Action": "Create Claim",
      "Category": "Claim",
      "Details": "User created a new claim",
      "IsSuccess": true
    },
    {
      "UserId": 117,
      "UserName": "SamanthaLopez",
      "Timestamp": "2024-04-02T14:48:14",
      "Action": "View Invoice",
      "Category": "Policy",
      "Details": "User viewed invoice details",
      "IsSuccess": true
    },
    {
      "UserId": 118,
      "UserName": "JacobHernandez",
      "Timestamp": "2024-04-01T10:20:05",
      "Action": "Login",
      "Category": "Auth",
      "Details": "User logged in successfully",
      "IsSuccess": true
    },
    {
      "UserId": 119,
      "UserName": "MadisonWalker",
      "Timestamp": "2024-03-31T16:38:39",
      "Action": "View Policy",
      "Category": "Policy",
      "Details": "User viewed policy details",
      "IsSuccess": true
    },
    {
      "UserId": 120,
      "UserName": "LoganYoung",
      "Timestamp": "2024-03-30T11:17:28",
      "Action": "Update Profile",
      "Category": "Auth",
      "Details": "User updated profile information",
      "IsSuccess": true
    }
  ]

  
const tableContainerStyle = {
  width: '80vw',
  margin: 'auto',
  marginTop: 20,
};

  const rowsPerPage = 10;

  export default function AuditLogAnalytics() {
    const [auditLogData, setAuditLogData] = useState([]);
    const [page, setPage] = useState(0);
    const [orderBy, setOrderBy] = useState('');
    const [order, setOrder] = useState('asc');
    const [filteredCategories, setFilteredCategories] = useState([]);
  
    useEffect(() => {
      setAuditLogData(mockdata);
    }, []);
  
    const handleSort = (property) => {
      const isAsc = orderBy === property && order === 'asc';
      setOrderBy(property);
      setOrder(isAsc ? 'desc' : 'asc');
    };
  
    const handleCategoryChange = (category) => {
      if (filteredCategories.includes(category)) {
        setFilteredCategories(filteredCategories.filter((cat) => cat !== category));
      } else {
        setFilteredCategories([...filteredCategories, category]);
      }
    };
  
    const filteredData = auditLogData.filter((row) => {
      if (filteredCategories.length === 0) return true;
      return filteredCategories.includes(row.Category);
    });
  
    const sortedData = filteredData.sort((a, b) => {
      if (order === 'asc') {
        return a[orderBy] > b[orderBy] ? 1 : -1;
      } else {
        return a[orderBy] < b[orderBy] ? 1 : -1;
      }
    });
  
    const pageCount = Math.ceil(sortedData.length / rowsPerPage);
  
    const handleNextPage = () => {
      setPage(Math.min(page + 1, pageCount - 1));
    };
  
    const handlePrevPage = () => {
      setPage(Math.max(page - 1, 0));
    };
  
    const startIndex = page * rowsPerPage;
    const endIndex = startIndex + rowsPerPage;
    const currentPageData = sortedData.slice(startIndex, endIndex);
  
    return (
      <>
        <div className="filter-container">
          <FormControlLabel
            control={<Checkbox checked={filteredCategories.includes('Auth')} onChange={() => handleCategoryChange('Auth')} />}
            label="Auth"
          />
          <FormControlLabel
            control={<Checkbox checked={filteredCategories.includes('Policy')} onChange={() => handleCategoryChange('Policy')} />}
            label="Policy"
          />
          <FormControlLabel
            control={<Checkbox checked={filteredCategories.includes('Claim')} onChange={() => handleCategoryChange('Claim')} />}
            label="Claim"
          />
        </div>
        <TableContainer component={Paper} style={tableContainerStyle}>
          <Table aria-label="audit log table">
            <TableHead>
              <TableRow>
                <TableCell>
                  <TableSortLabel
                    active={orderBy === 'UserId'}
                    direction={orderBy === 'UserId' ? order : 'asc'}
                    onClick={() => handleSort('UserId')}
                  >
                    User ID
                  </TableSortLabel>
                </TableCell>
                <TableCell>
                  <TableSortLabel
                    active={orderBy === 'UserName'}
                    direction={orderBy === 'UserName' ? order : 'asc'}
                    onClick={() => handleSort('UserName')}
                  >
                    User Name
                  </TableSortLabel>
                </TableCell>
                <TableCell>
                  <TableSortLabel
                    active={orderBy === 'Timestamp'}
                    direction={orderBy === 'Timestamp' ? order : 'asc'}
                    onClick={() => handleSort('Timestamp')}
                  >
                    Timestamp
                  </TableSortLabel>
                </TableCell>
                <TableCell>Action</TableCell>
                <TableCell>Category</TableCell>
                <TableCell>Details</TableCell>
                <TableCell>
                  <TableSortLabel
                    active={orderBy === 'IsSuccess'}
                    direction={orderBy === 'IsSuccess' ? order : 'asc'}
                    onClick={() => handleSort('IsSuccess')}
                  >
                    Success
                  </TableSortLabel>
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {currentPageData.map((row, index) => (
                <TableRow key={index}>
                  <TableCell>{row.UserId}</TableCell>
                  <TableCell>{row.UserName}</TableCell>
                  <TableCell>{row.Timestamp}</TableCell>
                  <TableCell>{row.Action}</TableCell>
                  <TableCell>{row.Category}</TableCell>
                  <TableCell>{row.Details}</TableCell>
                  <TableCell>{row.IsSuccess ? 'Yes' : 'No'}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
        <div>
          <Button onClick={handlePrevPage} disabled={page === 0}>Previous</Button>
          <span>{`Page ${page + 1} of ${pageCount}`}</span>
          <Button onClick={handleNextPage} disabled={page === pageCount - 1}>Next</Button>
        </div>
      </>
    );
  }